from django.db import models


gender=[
    ("M","Male"),
    ("F","Female"),
    ("U","Undisclosed"),
]



class Institute(models.Model):
    name=models.CharField(max_length=256)
    def __str__(self):
        return self.name


class Student(models.Model):
    name=models.CharField(max_length=256)
    rollno=models.IntegerField()
    college=models.ForeignKey('Institute',on_delete=models.CASCADE)

    Gender=models.CharField(max_length=1,choices=gender)
    def __str__(self):
        return self.name


# Create your models here.
