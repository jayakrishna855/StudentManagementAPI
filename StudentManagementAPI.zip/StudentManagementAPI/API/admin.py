from django.contrib import admin
from API import models
admin.site.register([
    models.Student,
    models.Institute
]
)

# Register your models here.
