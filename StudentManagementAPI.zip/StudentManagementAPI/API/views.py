from django.shortcuts import render
from API import models,serializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.generics import(
    ListAPIView,
    RetrieveAPIView,
    ListCreateAPIView
)

'''class StudentListView(ListAPIView):
    queryset=models.Student.objects.all()
    serializer_class=serializer.StudentsSerializer4
    '''
class StudentDetailView(RetrieveAPIView):
    queryset=models.Student.objects.all()
    serializer_class=serializer.StudentsSerializer
class StudentCreateView(ListCreateAPIView):
    queryset=models.Student.objects.all()
    serializer_class=serializer.StudentsSerializer

    



# Create your views here.
