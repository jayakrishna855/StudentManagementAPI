from django.urls import path
from API import views
urlpatterns=[
    path("students",views.StudentCreateView.as_view()),
    path("students/<int:pk>",views.StudentDetailView.as_view()),
]